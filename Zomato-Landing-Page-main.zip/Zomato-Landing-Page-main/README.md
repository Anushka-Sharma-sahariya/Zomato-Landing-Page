# Zomato Landing Page

A zomato Landing page created on HTML AND CSS.

Here you can see landing page:-https://zomatolanding-page.netlify.app/
